"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <nav className="sticky top-0 z-50 bg-black/95 backdrop-blur-md border-b border-yellow-500 shadow-[0_0_20px_rgba(255,215,0,0.15)]">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">

          <div className="flex items-center justify-between h-20">

            {/* Hamburger */}
            <button
              onClick={() => setMenuOpen(true)}
              className="md:hidden text-yellow-400 text-3xl"
            >
              ☰
            </button>

            {/* Logo */}
            <Link href="/" className="absolute left-1/2 -translate-x-1/2 md:static md:translate-x-0">
  <Image
    src="/logo.png"
    alt="ZKS Białogard"
    width={85}
    height={85}
    priority
  />
</Link>

            {/* Menu desktop */}
            <div className="hidden md:flex items-center gap-6 text-white font-medium">

              <Link
                href="/"
                className="hover:text-yellow-400 transition duration-200"
              >
                Strona główna
              </Link>

              <Link
                href="/zawody/najblizsze-zawody"
                className="hover:text-yellow-400 transition duration-200"
              >
                Najbliższe zawody
              </Link>
<Link
                href="/zawody/wyniki-zawodow"
                className="hover:text-yellow-400 transition duration-200"
              >
                Wyniki zawodów
              </Link>

              <Link
                href="/klub/o-klubie"
                className="hover:text-yellow-400 transition duration-200"
              >
                O Klubie
              </Link>

            
              <Link
                href="/galeria"
                className="hover:text-yellow-400 transition duration-200"
              >
                Galeria
              </Link>

              <Link
                href="/kontakt"
                className="hover:text-yellow-400 transition duration-200"
              >
                Kontakt
              </Link>

            </div>

            {/* Wyrównanie desktop */}
            <div className="hidden md:block w-8"></div>

          </div>
        </div>
      </nav>

      {/* Overlay */}
      {menuOpen && (
        <div
          className="fixed inset-0 bg-black/70 z-40 md:hidden"
          onClick={() => setMenuOpen(false)}
        />
      )}

      {/* Menu mobilne */}
      <div
        className={`fixed top-0 left-0 h-full w-72 bg-zinc-950 border-r border-yellow-500 z-50 transform transition-transform duration-300 md:hidden ${
          menuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-yellow-500">

          <span className="text-yellow-400 font-bold text-lg">
            Menu
          </span>

          <button
            onClick={() => setMenuOpen(false)}
            className="text-yellow-400 text-3xl"
          >
            ✕
          </button>

        </div>

        <div className="flex flex-col p-4 gap-4 text-white font-medium">

          <Link
  href="/"
  onClick={() => setMenuOpen(false)}
  className="px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
>
  🏠 Strona główna
</Link>

          <Link
  href="/zawody/najblizsze-zawody"
  onClick={() => setMenuOpen(false)}
  className="px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
>
  🤼 Najbliższe zawody
</Link>

          <Link
  href="/zawody/wyniki-zawodow"
  onClick={() => setMenuOpen(false)}
  className="px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
>
  🏅 Wyniki zawodów
</Link>

        <Link
  href="/klub/o-klubie"
  onClick={() => setMenuOpen(false)}
  className="px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
>
  💪 O Klubie
</Link>

          <Link
  href="/galeria"
  onClick={() => setMenuOpen(false)}
  className="px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
>
  📸 Galeria
</Link>

          <Link
  href="/kontakt"
  onClick={() => setMenuOpen(false)}
  className="px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
>
  📞 Kontakt
</Link>
<div className="mt-8 pt-6 border-t border-yellow-500/30">
  <a
    href="https://www.facebook.com/zksbialogard"
    target="_blank"
    rel="noopener noreferrer"
    className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-yellow-500/20 hover:text-yellow-400 transition-all duration-300"
  >
    📘 Facebook
  </a>
</div>
        </div>
      </div>
    </>
  );
}