"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import {
  collection,
  getDocs,
  query,
  where,
  doc,
  updateDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase";

interface Registration {
  id: string;
  childName: string;
  childSurname: string;
  childBirthYear: string;
  childGender: string;
  childWeight: string;
  parentPhone?: string;
  status: string;
}

interface EventType {
  id: string;
  name: string;
  city: string;
  date: string;
}

export default function EventRegistrationsPage() {
  const params = useParams();

  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [eventData, setEventData] = useState<EventType | null>(null);
  const [loading, setLoading] = useState(true);

  const [filter, setFilter] = useState<
    "all" | "accepted" | "pending" | "rejected"
  >("all");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const eventSnapshot = await getDocs(
        query(
          collection(db, "events"),
          where("__name__", "==", String(params.id))
        )
      );

      if (!eventSnapshot.empty) {
        const eventDoc = eventSnapshot.docs[0];

        setEventData({
          id: eventDoc.id,
          ...(eventDoc.data() as Omit<EventType, "id">),
        });
      }

      const registrationsSnapshot = await getDocs(
        query(
          collection(db, "registrations"),
          where("eventId", "==", String(params.id))
        )
      );

      const data = registrationsSnapshot.docs.map((document) => ({
        id: document.id,
        ...(document.data() as Omit<Registration, "id">),
      }));

      setRegistrations(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (
    registrationId: string,
    status: string
  ) => {
    try {
      await updateDoc(
        doc(db, "registrations", registrationId),
        { status }
      );

      setRegistrations((prev) =>
        prev.map((item) =>
          item.id === registrationId
            ? { ...item, status }
            : item
        )
      );
    } catch (error) {
      console.error(error);
      alert("Błąd aktualizacji statusu.");
    }
  };

  const exportToExcel = () => {
    const acceptedRegistrations = registrations.filter(
      (registration) => registration.status === "accepted"
    );
    

    if (acceptedRegistrations.length === 0) {
      alert("Brak zaakceptowanych zawodników.");
      return;
    }

    const data = acceptedRegistrations.map((registration) => ({
      "Imię i nazwisko":
        `${registration.childName} ${registration.childSurname}`,
      Klub: "ZKS Białogard",
      Rocznik: registration.childBirthYear,
      Płeć:
        registration.childGender === "M"
          ? "Mężczyzna"
          : "Kobieta",
      "Kategoria wagowa":
        `${registration.childWeight} kg`,
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(
      workbook,
      worksheet,
      "Lista startowa"
    );

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const fileData = new Blob([excelBuffer], {
      type:
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const fileName = eventData
      ? `${eventData.name}_Lista_Startowa.xlsx`
      : "Lista_Startowa.xlsx";

    saveAs(fileData, fileName);
  };

  const acceptedCount = registrations.filter(
    (r) => r.status === "accepted"
  ).length;

  const rejectedCount = registrations.filter(
    (r) => r.status === "rejected"
  ).length;

  const pendingCount = registrations.filter(
    (r) => r.status === "pending" || !r.status
  ).length;

  const filteredRegistrations = registrations.filter((r) => {
    if (filter === "all") return true;

    if (filter === "pending") {
      return r.status === "pending" || !r.status;
    }

    return r.status === filter;
  });

  const getStatusText = (status: string) => {
    switch (status) {
      case "accepted":
        return "Zaakceptowany";
      case "rejected":
        return "Odrzucony";
      default:
        return "Oczekujący";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "accepted":
        return "text-green-400";
      case "rejected":
        return "text-red-400";
      default:
        return "text-yellow-400";
    }
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <div className="max-w-6xl mx-auto">

        <div className="flex flex-wrap gap-3 mb-6">
          <Link
            href="/admin/zawody"
            className="bg-zinc-800 hover:bg-zinc-700 px-4 py-2 rounded-xl"
          >
            ← Powrót do zawodów
          </Link>

          <button
            onClick={exportToExcel}
            className="bg-green-600 hover:bg-green-500 px-4 py-2 rounded-xl font-bold"
          >
            📊 Pobierz Excel
          </button>
        </div>
      </div>
    </main>
  );
}